"""Streamlit entrypoint for the ChessBot coaching dashboard."""

import streamlit as st

from core.config import load_config


def main() -> None:
    st.set_page_config(page_title="ChessBot", page_icon="♟", layout="wide")
    config = load_config()

    st.title("ChessBot")
    st.write("Learn from your tactical blunders with guidance from your chess books.")

    with st.sidebar:
        st.header("Player")
        st.write(config.chess_com_username or "Set CHESS_COM_USERNAME in .env")

    st.info(
        "This is the starter dashboard. Game import, tactical analysis, and "
        "book-based coaching will be added in the next stage."
    )


if __name__ == "__main__":
    main()
