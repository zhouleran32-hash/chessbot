# ChessBot

A Python starter project for a chess coaching dashboard that will combine
Chess.com games, python-chess and Stockfish analysis, and principles retrieved
from uploaded chess book PDFs using ChromaDB.

## Project structure

```text
ChessBot/
├── core/
│   ├── __init__.py
│   ├── config.py       # Environment and local storage settings
│   ├── chess_com.py    # Chess.com client placeholder
│   ├── analysis.py     # Stockfish analysis placeholder
│   └── rag.py          # PDF ingestion and retrieval placeholder
├── data/
│   ├── cache/          # Local SQLite cache
│   ├── books/          # Uploaded chess book PDFs
│   └── chroma/         # Persistent ChromaDB vector store
├── app.py
├── requirements.txt
└── .env.example
```

## Setup

From the project folder:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
cp .env.example .env
```

On Windows, activate the environment with `.venv\Scripts\activate` instead.

Edit `.env` with your OpenAI API key and Chess.com username. Install the Stockfish
executable separately and set `STOCKFISH_PATH` to its full path, or leave it as
`stockfish` if it is available on your system PATH.

Place your chess book PDFs in `data/books/`.

```sh
streamlit run app.py
```

## Configuration

`core.config.load_config()` reads the project-root `.env` file. Existing
environment variables take precedence. The project can start without credentials;
the default username and API key are empty, and the default engine is `stockfish`.

Storage paths are absolute paths based on the project folder, so they do not
depend on the current working directory:

- SQLite cache: `data/cache/games.sqlite3`
- Book PDFs: `data/books/`
- ChromaDB vector store: `data/chroma/`

The SQLite database and vector store will be created when their integrations are
implemented. Local data and `.env` are excluded from version control.

This scaffold includes a starter Streamlit screen and configuration loader. The
Chess.com client, engine analysis, and RAG modules are placeholders.
