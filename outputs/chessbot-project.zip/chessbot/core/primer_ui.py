"""Guided, source-referenced Primer teaching and interactive practice."""

import sqlite3
from urllib.parse import quote

import chess
import chess.svg
import streamlit as st

from core.primer import CHAPTER_TITLES, Step, feedback_for_played_move, lessons, san_for_squares, step_svg
from core.primer_progress import LearningProgress
from core.primer_study import BOOK_CHAPTERS, check_concept, concept_option_order, example_frames, guide_for, required_checks


_PIECE_SYMBOL = {
    "K": "♔", "Q": "♕", "R": "♖", "B": "♗", "N": "♘", "P": "♙",
    "k": "♚", "q": "♛", "r": "♜", "b": "♝", "n": "♞", "p": "♟",
}


def _square_is_dark(square: str) -> bool:
    return ("abcdefgh".index(square[0]) + int(square[1])) % 2 == 1


def _reset_quiz_position() -> None:
    st.session_state.primer_board_fen = None
    st.session_state.primer_from = None
    st.session_state.primer_promotion = None
    st.session_state.primer_moved = None
    st.session_state.primer_feedback = None
    st.session_state.primer_try = st.session_state.get("primer_try", 0) + 1


def _set_primer_lesson(lesson_id: str) -> None:
    st.session_state.primer_lesson = lesson_id
    st.session_state.primer_chapter = next(item.chapter for item in lessons() if item.id == lesson_id)
    st.session_state.primer_step = 0
    _reset_quiz_position()


def _play_quiz_move(lesson, move: chess.Move) -> None:
    board = chess.Board(lesson.quiz_fen)
    san = board.san(move)
    board.push(move)
    st.session_state.primer_board_fen = board.fen()
    st.session_state.primer_moved = (
        chess.square_name(move.from_square), chess.square_name(move.to_square), san,
    )
    st.session_state.primer_from = None
    st.session_state.primer_promotion = None
    result = feedback_for_played_move(lesson, san)
    st.session_state.primer_feedback = (result.correct, result.explanation)
    _record_result(lesson.id, "board", result.correct)


def _choose_quiz_square(lesson, square: str) -> None:
    """Select a piece, or move the selected piece onto this square."""
    if st.session_state.get("primer_board_fen"):
        return
    board = chess.Board(lesson.quiz_fen)
    origin = st.session_state.get("primer_from")
    target = chess.parse_square(square)
    if origin:
        moves = [
            move for move in board.legal_moves
            if chess.square_name(move.from_square) == origin and move.to_square == target
        ]
        if len(moves) > 1:
            st.session_state.primer_promotion = (origin, square)
            return
        if len(moves) == 1:
            _play_quiz_move(lesson, moves[0])
            return
    piece = board.piece_at(target)
    if piece and piece.color == board.turn and any(move.from_square == target for move in board.legal_moves):
        st.session_state.primer_from = square if origin != square else None
    else:
        st.session_state.primer_from = None


def _quiz_square_key(lesson_id: str, square: str, piece: chess.Piece | None, attempt: int) -> str:
    shade = "light" if not _square_is_dark(square) else "dark"
    token = "E" if piece is None else f"P{piece.symbol()}"
    return f"quiz-{lesson_id}-{square}-{attempt}-{token}-{shade}"


def _quiz_board_style() -> str:
    rules = [
        "div[class*='st-key-quiz-'] button { width: 100%; aspect-ratio: 1; min-height: 0; height: auto; "
        "padding: 0; border: none !important; border-radius: 0 !important; min-width: 0; "
        "background-repeat: no-repeat; background-position: center; background-size: 82%; "
        "font-size: 0; color: transparent; line-height: 0; }",
        "div[class*='st-key-quiz-'][class*='-light'] button { background-color: #f0d9b5; }",
        "div[class*='st-key-quiz-'][class*='-dark'] button { background-color: #b58863; }",
        "div[class*='st-key-quiz-'][class*='-E-'] button { font-size: 1.35rem; color: #1B7F4E; line-height: 1; }",
        "div[class*='st-key-quiz-'] button[kind='primary'] { outline: 3px solid #145A32; outline-offset: -3px; }",
        "div[class*='st-key-quiz_board_frame'] [data-testid='stVerticalBlock'] { gap: 0 !important; }",
        "div[class*='st-key-quiz_board_frame'] [data-testid='stHorizontalBlock'] { flex-wrap: nowrap !important; }",
        "div[class*='st-key-quiz_board_frame'] [data-testid='stColumn'] { min-width: 0 !important; flex: 1 1 0 !important; width: auto !important; }",
    ]
    for symbol in "KQRBNPkqrbnp":
        svg = quote(chess.svg.piece(chess.Piece.from_symbol(symbol), size=64), safe="")
        rules.append(
            f"div[class*='st-key-quiz-'][class*='-P{symbol}-'] button "
            f"{{ background-image: url('data:image/svg+xml,{svg}'); }}"
        )
    return "<style>" + " ".join(rules) + "</style>"


def _quiz_board(lesson, fen: str) -> str | None:
    """Draw a clickable board. Return the square clicked on this run."""
    board = chess.Board(fen)
    orientation = lesson.orientation
    files = "abcdefgh" if orientation == "white" else "hgfedcba"
    ranks = range(8, 0, -1) if orientation == "white" else range(1, 9)
    origin = st.session_state.get("primer_from")
    targets = set()
    if origin and not st.session_state.get("primer_board_fen"):
        targets = {
            chess.square_name(move.to_square)
            for move in chess.Board(lesson.quiz_fen).legal_moves
            if chess.square_name(move.from_square) == origin
        }
    moved = st.session_state.get("primer_moved") or ()
    attempt = st.session_state.get("primer_try", 0)
    clicked = None
    board_frame = st.container(width=560, gap=None, key="quiz_board_frame")
    with board_frame:
        clicked = _quiz_squares(lesson, board, files, ranks, origin, targets, moved, attempt)
        _quiz_files(files)
    return clicked


def _quiz_squares(lesson, board, files, ranks, origin, targets, moved, attempt) -> str | None:
    clicked = None
    for rank in ranks:
        row = st.columns([0.35, *([1] * 8)], gap=None, wrap=False)
        row[0].markdown(f"<div style='text-align:center;color:#6b7280;padding-top:0.65rem'>{rank}</div>", unsafe_allow_html=True)
        for index, file in enumerate(files):
            square = f"{file}{rank}"
            piece = board.piece_at(chess.parse_square(square))
            if square in targets and piece is None:
                label = "•"
            else:
                label = _PIECE_SYMBOL.get(piece.symbol(), "\u00a0") if piece else "\u00a0"
            marked = square == origin or square in targets or square in moved[:2]
            if row[index + 1].button(
                label, key=_quiz_square_key(lesson.id, square, piece, attempt),
                help=square, type="primary" if marked else "secondary", width="stretch",
            ):
                clicked = square
    return clicked


def _quiz_files(files) -> None:
    letters = st.columns([0.35, *([1] * 8)], gap=None, wrap=False)
    letters[0].markdown("")
    for index, file in enumerate(files):
        letters[index + 1].markdown(
            f"<div style='text-align:center;color:#6b7280;padding:0.45rem 0 0.9rem;font-weight:600'>{file}</div>",
            unsafe_allow_html=True,
        )


def _prepare_progress(config) -> dict[str, set[str]]:
    player = (st.session_state.get("username") or config.chess_com_username or "local-learner").strip() or "local-learner"
    path = config.sqlite_path.parent / "primer.sqlite3"
    identity = (str(path), player.casefold())
    if st.session_state.get("primer_profile") != identity:
        st.session_state.primer_profile = identity
        st.session_state.primer_passed = {}
        st.session_state.primer_concept_feedback = {}
        for key in list(st.session_state):
            if key in {"primer_lesson", "primer_chapter", "primer_shown"} or key.startswith(("concept_choice_", "concept_check_", "worked_", "example_")):
                del st.session_state[key]
        _reset_quiz_position()
        try:
            store = LearningProgress(path, player)
            st.session_state.primer_progress_store = store
            st.session_state.primer_passed = store.all_passed()
            saved = store.last_lesson()
            if saved:
                st.session_state.primer_lesson = saved
        except (OSError, sqlite3.Error):
            st.session_state.primer_progress_store = None
            st.warning("Lessons work, but progress could not be saved locally. Check the data/cache folder permissions.")
    return st.session_state.primer_passed


def _record_result(lesson_id: str, exercise: str, correct: bool) -> None:
    if correct:
        st.session_state.primer_passed.setdefault(lesson_id, set()).add(exercise)
    store = st.session_state.get("primer_progress_store")
    if store:
        try:
            store.record(lesson_id, exercise, correct)
        except (OSError, sqlite3.Error):
            st.warning("Your answer was checked, but progress could not be saved to disk.")


def _bookmark(lesson_id: str) -> None:
    store = st.session_state.get("primer_progress_store")
    if store:
        try:
            store.bookmark(lesson_id)
        except (OSError, sqlite3.Error):
            st.warning("Your place in the course could not be saved to disk.")


def _course_navigation(catalog, passed):
    by_id = {item.id: item for item in catalog}
    if st.session_state.get("primer_lesson") not in by_id:
        st.session_state.primer_lesson = catalog[0].id
    if "primer_chapter" not in st.session_state:
        st.session_state.primer_chapter = by_id[st.session_state.primer_lesson].chapter
    chapter = st.selectbox("Chapter", sorted({item.chapter for item in catalog}), format_func=lambda n: f"Chapter {n} · {CHAPTER_TITLES[n]}", key="primer_chapter", filter_mode=None)
    chapter_ids = [item.id for item in catalog if item.chapter == chapter]
    if st.session_state.primer_lesson not in chapter_ids:
        st.session_state.primer_lesson = chapter_ids[0]
    selected = st.selectbox(
        "Lesson", chapter_ids, key="primer_lesson", filter_mode=None,
        format_func=lambda identifier: f"Chapter {by_id[identifier].chapter} · {CHAPTER_TITLES[by_id[identifier].chapter]} · {by_id[identifier].title}",
    )
    if st.session_state.get("primer_shown") != selected:
        st.session_state.primer_shown = selected
        st.session_state.primer_step = 0
        _reset_quiz_position()
        # Initial attempts retain stable board keys for keyboard/accessibility use.
        st.session_state.primer_try = 0
        _bookmark(selected)
    index = [item.id for item in catalog].index(selected)
    previous, following = st.columns(2)
    previous.button("Previous lesson", disabled=index == 0, key="primer_previous_lesson", on_click=_set_primer_lesson, args=(catalog[max(0, index - 1)].id,))
    following.button("Next lesson", disabled=index == len(catalog) - 1, key="primer_next_lesson", on_click=_set_primer_lesson, args=(catalog[min(len(catalog) - 1, index + 1)].id,))
    return by_id[selected], index


def _introductory_diagrams(lesson) -> None:
    with st.expander("Introductory diagrams", expanded=False):
        index = min(st.session_state.get("primer_step", 0), len(lesson.steps) - 1)
        step = lesson.steps[index]
        st.image(step_svg(step, lesson.orientation), width="stretch")
        st.caption(f"Step {index + 1} of {len(lesson.steps)}. {step.caption}")
        back, forward = st.columns(2)
        if back.button("Back", disabled=index == 0, key="primer_back"):
            st.session_state.primer_step = index - 1
            st.rerun()
        if forward.button("Next", disabled=index == len(lesson.steps) - 1, key="primer_next"):
            st.session_state.primer_step = index + 1
            st.rerun()


def _learn(lesson, guide: dict | None) -> None:
    if guide:
        st.markdown("**By the end of this lesson, you should be able to:**")
        for goal in guide["goals"]:
            st.markdown(f"- {goal}")
    if not guide or not any(section["body"].strip() == lesson.explanation.strip() for section in guide["sections"]):
        st.markdown(lesson.explanation)
    if guide:
        for section in guide["sections"]:
            st.markdown(f"#### {section['title']}")
            st.markdown(section["body"])
        st.markdown("#### Common mistakes to avoid")
        for misconception in guide["pitfalls"]:
            st.markdown(f"- {misconception}")
    _introductory_diagrams(lesson)


def _step_example(position_key: str, direction: int, last_position: int) -> None:
    st.session_state[position_key] = max(0, min(st.session_state[position_key] + direction, last_position))


def _worked_examples(lesson, guide: dict | None) -> None:
    if not guide:
        st.info("A detailed worked example is being prepared for this lesson.")
        return
    examples = guide["examples"]
    example_index = st.selectbox("Worked example", list(range(len(examples))), format_func=lambda index: examples[index]["title"], key=f"worked_{lesson.id}", filter_mode=None) if len(examples) > 1 else 0
    example = examples[example_index]
    st.markdown(f"#### {example['title']}")
    frames = example_frames(example)
    position_key = f"example_{lesson.id}_{example_index}"
    move_index = max(0, min(st.session_state.get(position_key, 0), len(frames) - 1))
    st.session_state[position_key] = move_index
    frame = frames[move_index]
    board_column, explanation_column = st.columns([1, 1], gap="large")
    with board_column:
        arrows = [chess.svg.Arrow(chess.parse_square(frame.arrow[0]), chess.parse_square(frame.arrow[1]), color="#1B7F4E")] if frame.arrow else []
        st.image(chess.svg.board(chess.Board(frame.fen), orientation=lesson.orientation == "white", arrows=arrows, size=480), width="stretch", alt=f"Worked example: {frame.move_label}")
        previous, following = st.columns(2, gap="small", wrap=False)
        previous.button(
            "<", key=f"example_previous_{lesson.id}_{example_index}", help="Previous move",
            disabled=move_index == 0, width="stretch", on_click=_step_example,
            args=(position_key, -1, len(frames) - 1),
        )
        following.button(
            ">", key=f"example_next_{lesson.id}_{example_index}", help="Next move",
            disabled=move_index == len(frames) - 1, width="stretch", on_click=_step_example,
            args=(position_key, 1, len(frames) - 1),
        )
    with explanation_column:
        st.markdown(f"**{frame.move_label}**")
        st.markdown(frame.note)
        st.caption(f"Position {move_index + 1} of {len(frames)}. Use the buttons below the board to move one step at a time and explain what changed before reading on.")
        st.markdown("**The complete line**")
        st.write(" · ".join(item.move_label for item in frames[1:]))


def _board_practice(lesson) -> None:
    st.markdown("**Your turn**")
    st.write(lesson.prompt)
    st.caption("Click a piece, then its destination. Legal destinations are highlighted. You can also choose a move by name.")
    st.markdown(_quiz_board_style(), unsafe_allow_html=True)
    display_fen = st.session_state.get("primer_board_fen") or lesson.quiz_fen
    chosen_square = _quiz_board(lesson, display_fen)
    if chosen_square:
        _choose_quiz_square(lesson, chosen_square)
        st.rerun()
    promotion = st.session_state.get("primer_promotion")
    if promotion:
        st.caption("Choose the piece this pawn becomes.")
        for column, (name, symbol) in zip(st.columns(4), (("Queen", "q"), ("Rook", "r"), ("Bishop", "b"), ("Knight", "n"))):
            if column.button(name, key=f"promo-{lesson.id}-{symbol}"):
                san = san_for_squares(lesson.quiz_fen, promotion[0], promotion[1], promotion=symbol)
                if san:
                    _play_quiz_move(lesson, chess.Board(lesson.quiz_fen).parse_san(san))
                    st.rerun()
    st.caption("Or choose the move by name")
    for column, choice in zip(st.columns(len(lesson.choices), gap="medium"), lesson.choices):
        if column.button(choice.san, key=f"primer-choice-{lesson.id}-{choice.san}"):
            _play_quiz_move(lesson, chess.Board(lesson.quiz_fen).parse_san(choice.san))
            st.rerun()
    moved = st.session_state.get("primer_moved")
    if moved:
        st.caption(f"You played {moved[2]}.")
    feedback = st.session_state.get("primer_feedback")
    if feedback:
        (st.success if feedback[0] else st.warning)(feedback[1])
    if st.session_state.get("primer_board_fen") and st.button("Try again", key="primer_try_again"):
        _reset_quiz_position()
        st.rerun()


def _concept_checks(lesson, guide: dict | None) -> None:
    if not guide:
        return
    st.markdown("#### Explain the idea")
    st.caption("These questions check why the move or rule works. Every answer has an explanation.")
    results = st.session_state.primer_concept_feedback
    for number, question in enumerate(guide["checks"], start=1):
        with st.container(border=True):
            choice = st.radio(
                f"{number}. {question['prompt']}", concept_option_order(lesson.id, question), index=None,
                format_func=lambda index, options=question["options"]: options[index]["text"],
                key=f"concept_choice_{lesson.id}_{question['id']}",
            )
            if st.button("Check my answer", key=f"concept_check_{lesson.id}_{question['id']}", disabled=choice is None):
                result = check_concept(guide, question["id"], choice)
                results[(lesson.id, question["id"])] = (choice, result)
                _record_result(lesson.id, f"concept:{question['id']}", result.correct)
                st.rerun()
            checked = results.get((lesson.id, question["id"]))
            if isinstance(checked, tuple):
                checked_choice, result = checked
                if checked_choice == choice:
                    (st.success if result.correct else st.warning)(result.explanation)
                else:
                    st.info("Check your changed answer to see its explanation.")


def _review(lesson, guide, passed) -> None:
    st.markdown("#### What to remember")
    for point in (guide or {}).get("recap", ()):
        st.markdown(f"- {point}")
    required = required_checks(guide)
    completed = passed.get(lesson.id, set()) & required
    st.progress(len(completed) / len(required), text=f"{len(completed)} of {len(required)} practice checks completed")
    if completed == required:
        st.success("Lesson practice completed. Revisit the example later and try explaining the idea without the notes.")
    else:
        st.info("Complete the board task and each understanding check in Practice. Your place and successful checks are saved locally.")
    st.markdown("**Take it into a game:** Before your next move, name the idea from this lesson and explain whether it applies to the position in front of you.")


def render_primer(config) -> None:
    catalog = lessons()
    passed = _prepare_progress(config)
    st.subheader("Learn The Soviet Chess Primer")
    available_chapters = {item.chapter for item in catalog}
    last_chapter = max(available_chapters)
    st.caption(f"Detailed guided teaching for chapters 1–{last_chapter}, with original explanations and checked chess positions.")
    with st.expander("Course coverage and how to study"):
        st.write("Read one idea, replay the line slowly, try a different move, then do the practice. Short, attentive sessions are more useful than rushing through many lessons.")
        remaining = (f"Chapters {last_chapter + 1}–10 and the appendix are not yet taught here."
                     if last_chapter < 10 else "The appendix is not yet taught here.")
        st.write(f"This course develops the concepts in chapters 1–{last_chapter}, using detailed explanations, annotated games and studies, and practice with feedback. Not every printed entertainment puzzle or variation is reproduced. {remaining}")
        for number, (title, start, end) in BOOK_CHAPTERS.items():
            state = "Guided lessons available" if number in available_chapters else "Not yet taught"
            st.markdown(f"- **Chapter {number}: {title}** · pp. {start}–{end} · {state}")
    completed = sum(required_checks(guide_for(item.id, item.chapter)) <= passed.get(item.id, set()) for item in catalog)
    st.progress(completed / len(catalog), text=f"{completed} of {len(catalog)} lessons: practice completed")
    lesson, index = _course_navigation(catalog, passed)
    guide = guide_for(lesson.id, lesson.chapter)
    st.markdown(f"### {lesson.title}")
    st.caption(f"Chapter {lesson.chapter} · {CHAPTER_TITLES[lesson.chapter]} · lesson {index + 1} of {len(catalog)}")
    if guide:
        start, end = guide["pages"]
        st.caption(f"Book reference: printed pages {start}–{end} · PDF pages {start + 1}–{end + 1}")
    learn_tab, example_tab, practice_tab, review_tab = st.tabs(["Learn", "Worked examples", "Practice", "Review"])
    with learn_tab:
        _learn(lesson, guide)
    with example_tab:
        _worked_examples(lesson, guide)
    with practice_tab:
        _board_practice(lesson)
        _concept_checks(lesson, guide)
    with review_tab:
        _review(lesson, guide, passed)


