"""Exercise the dashboard through Streamlit widgets with external work isolated."""

import copy
from contextlib import ExitStack
from dataclasses import replace
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import MagicMock, patch

import chess
import chess.svg
from streamlit.testing.v1 import AppTest

from core.analyzer import EngineUnavailableError, GameAnalysisError
from core.chess_client import ChessDotComTimeoutError
from core.config import Settings
from core.coach import CoachingError
from core.rag_engine import KnowledgeBaseError


ROOT = Path(__file__).resolve().parents[1]
PGN = "1. e4 e5 2. Qh5 Nc6 3. Qxe5+ Nxe5 0-1"
board = chess.Board()
for san in ("e4", "e5", "Qh5", "Nc6"):
    board.push_san(san)
BLUNDER = {
    "move_number": 3, "fen_before": board.fen(), "played_move": "Qxe5+",
    "best_move": "Bc4", "eval_drop": 8.73,
    "board_svg": chess.svg.board(board),
}


def game(number, **changes):
    row = {
        "game_url": f"https://www.chess.com/game/live/{number}",
        "played_at": f"2026-10-{number:02d}T12:00:00+00:00",
        "white_username": "Alice", "white_rating": 700,
        "black_username": "Bob", "black_rating": 720,
        "user_color": "white", "result": "loss", "pgn": PGN,
    }
    return row | changes


class DashboardTests(unittest.TestCase):
    def setUp(self):
        self.stack = ExitStack()
        self.addCleanup(self.stack.close)
        temp = Path(self.stack.enter_context(tempfile.TemporaryDirectory()))
        self.config = replace(Settings(), stockfish_path="fixture-stockfish", sqlite_path=temp / "cache" / "games.sqlite3", books_dir=temp / "books", chroma_dir=temp / "chroma", review_only=False)
        self.stack.enter_context(patch("core.config.load_config", side_effect=lambda: self.config))
        self.stack.enter_context(patch.dict(os.environ, {"ANTHROPIC_API_KEY": "", "ANTHROPIC_MODEL": ""}))
        self.fetch = self.stack.enter_context(patch("core.chess_client.ChessDotComClient.get_recent_games", return_value=[game(2, accuracy=86.4), game(1)]))
        self.analysis_calls = []
        self.analysis_error = None
        self.blunders = [BLUNDER, BLUNDER | {"eval_drop": 2.0}]
        self.engine_missing = False

        def make_analyzer(*args, **kwargs):
            if self.engine_missing and not kwargs.get("allow_mock"):
                raise EngineUnavailableError("Set STOCKFISH_PATH to a valid executable.")
            analyzer = MagicMock()
            analyzer.is_mock = self.engine_missing
            analyzer.__enter__.return_value = analyzer

            def analyze(pgn, color, **options):
                self.analysis_calls.append((pgn, color))
                if self.analysis_error:
                    raise self.analysis_error
                callback = options["progress_callback"]
                callback(0, 6)
                callback(6, 6)
                return copy.deepcopy(self.blunders)

            analyzer.analyze_game.side_effect = analyze
            return analyzer

        self.stack.enter_context(patch("core.analyzer.GameAnalyzer", side_effect=make_analyzer))
        self.kb = MagicMock()
        self.kb.search_advice.return_value = ["Protect your pieces.\n\n[Source: Built-in beginner principles | page n/a]"]
        self.kb.ingest_pdf.return_value = 4
        self.stack.enter_context(patch("core.rag_engine.ChessBookKnowledgeBase", return_value=self.kb))
        self.app = AppTest.from_file(str(ROOT / "app.py"), default_timeout=15)

    def run_app(self):
        self.app.run()
        self.assertEqual(list(self.app.exception), [])
        return self.app

    def button(self, label):
        return next(button for button in self.app.button if button.label == label)

    def fetch_games(self):
        self.run_app()
        self.app.text_input(key="username").set_value("Alice")
        self.button("Fetch Games").click()
        self.run_app()

    def choose(self, number=2):
        self.app.selectbox(key="selected_game").select(f"https://www.chess.com/game/live/{number}")
        return self.run_app()

    def text(self):
        return "\n".join(item.value for kind in (self.app.markdown, self.app.caption, self.app.info, self.app.warning, self.app.success, self.app.error) for item in kind)

    def test_empty_dashboard_has_sidebar_controls_and_no_automatic_fetch(self):
        self.run_app()
        self.assertEqual(self.app.title[0].value, "ChessBot")
        self.assertEqual(self.app.file_uploader[0].label, "Feed a Chess Book")
        self.assertTrue(self.button("Generate My Weekly Improvement Plan").disabled)
        self.fetch.assert_not_called()

    def test_selection_analyzes_once_slider_reruns_and_weekly_plan_uses_each_game_once(self):
        self.fetch_games()
        self.assertEqual(list(self.app.dataframe[0].value.columns), ["White", "Black", "Result", "Date (UTC)"])
        self.choose()
        self.assertEqual(len(self.analysis_calls), 1)
        self.assertEqual(next(metric.value for metric in self.app.metric if metric.label == "Accuracy"), "86.4%")
        self.assertIn("[Source: Built-in beginner principles", self.text())
        self.app.slider[0].set_value(2)
        self.run_app()
        self.assertEqual(len(self.analysis_calls), 1)
        self.choose(1)
        self.assertEqual(next(metric.value for metric in self.app.metric if metric.label == "Accuracy"), "—")
        self.choose(2)
        self.assertEqual(len(self.analysis_calls), 2)
        self.button("Generate My Weekly Improvement Plan").click()
        self.run_app()
        self.assertIn("2 games", self.text())
        self.assertIn("4 blunders", self.text())
        self.assertIn("Focus 1:", self.text())

    def test_fetch_error_preserves_loaded_games_and_can_recover(self):
        self.fetch_games()
        self.fetch.side_effect = ChessDotComTimeoutError("Chess.com timed out. Try again.")
        self.button("Fetch Games").click()
        self.run_app()
        self.assertIn("timed out", self.text())
        self.assertEqual(len(self.app.dataframe[0].value), 2)
        self.fetch.side_effect = None
        self.button("Fetch Games").click()
        self.run_app()
        self.assertNotIn("timed out", self.text())

    def test_mock_mode_is_labeled_and_can_be_disabled(self):
        self.engine_missing = True
        self.fetch_games()
        self.assertFalse(self.app.checkbox(key="allow_mock").value)
        self.choose()
        self.assertEqual(self.analysis_calls, [])
        self.assertIn("STOCKFISH_PATH", self.text())
        self.app.checkbox(key="allow_mock").check()
        self.run_app()
        self.assertEqual(len(self.analysis_calls), 1)
        self.assertIn("Mock analysis", self.text())

    def test_failed_analysis_waits_for_explicit_retry(self):
        self.analysis_error = GameAnalysisError("Stockfish stopped unexpectedly.")
        self.fetch_games()
        self.choose()
        self.assertIsNotNone(self.button("Retry analysis"))
        self.run_app()
        self.assertEqual(len(self.analysis_calls), 1)
        self.analysis_error = None
        self.button("Retry analysis").click()
        self.run_app()
        self.assertEqual(len(self.analysis_calls), 2)
        self.assertTrue(self.app.metric)

    def test_pdf_indexes_once_preserves_filename_and_allows_explicit_retry(self):
        self.run_app()
        self.kb.ingest_pdf.side_effect = KnowledgeBaseError("Set OPENAI_API_KEY for book indexing.")
        self.app.file_uploader[0].set_value(("../tactics.pdf", b"%PDF-fixture", "application/pdf"))
        self.run_app()
        self.assertIsNotNone(self.button("Retry indexing"))
        self.run_app()
        self.assertEqual(self.kb.ingest_pdf.call_count, 1)
        self.kb.ingest_pdf.side_effect = None
        self.button("Retry indexing").click()
        self.run_app()
        self.assertEqual(self.kb.ingest_pdf.call_count, 2)
        path = Path(self.kb.ingest_pdf.call_args.args[0])
        self.assertEqual(path.name, "tactics.pdf")
        self.assertTrue(path.is_relative_to(self.config.books_dir))
        self.assertEqual(path.read_bytes(), b"%PDF-fixture")
        self.run_app()
        self.assertEqual(self.kb.ingest_pdf.call_count, 2)
        self.assertIn("4 passages", self.text())

    def test_ai_review_is_cached_and_new_book_refreshes_context(self):
        self.config = replace(self.config, openai_api_key="test-key")
        self.stack.enter_context(patch("openai.OpenAI", return_value=MagicMock()))
        review = self.stack.enter_context(patch("core.coach.ChessCoach.review_blunder", return_value="**The Tactical Breakdown**\nKeep your queen safe.\n\n**The Principle from the Books**\n[Source: tactics.pdf | page 7]\n\n**The Mental Check**\nWhat can be captured?"))
        self.fetch_games()
        self.choose()
        self.run_app()
        self.assertEqual(review.call_count, 1)
        self.assertIn("tactics.pdf | page 7", self.text())
        self.assertEqual(review.call_args.kwargs["user_rating"], 700)
        self.app.file_uploader[0].set_value(("tactics.pdf", b"%PDF-new", "application/pdf"))
        self.run_app()
        self.assertEqual(review.call_count, 2)

    def test_ai_failure_is_not_automatically_repeated(self):
        self.config = replace(self.config, openai_api_key="test-key")
        self.stack.enter_context(patch("openai.OpenAI", return_value=MagicMock()))
        review = self.stack.enter_context(patch("core.coach.ChessCoach.review_blunder", side_effect=CoachingError("Could not generate coaching feedback.")))
        self.fetch_games()
        self.choose()
        self.assertIsNotNone(self.button("Retry coaching"))
        self.run_app()
        self.assertEqual(review.call_count, 1)
        self.assertIn("Could not generate", self.text())
        review.side_effect = None
        review.return_value = "**The Mental Check**\nWhat can be captured?"
        self.button("Retry coaching").click()
        self.run_app()
        self.assertEqual(review.call_count, 2)

    def test_zero_blunders_is_a_complete_analysis_and_has_no_slider(self):
        self.blunders = []
        self.fetch_games()
        self.choose()
        self.assertIn("No blunders", self.text())
        self.assertFalse(any(slider.label == "Blunder" for slider in self.app.slider))
        self.assertFalse(self.button("Generate My Weekly Improvement Plan").disabled)

    def test_switching_players_resets_session_analysis(self):
        self.fetch_games()
        self.choose()
        self.app.text_input(key="username").set_value("Charlie")
        self.fetch.return_value = [game(3, white_username="Charlie")]
        self.button("Fetch Games").click()
        self.run_app()
        self.assertTrue(self.button("Generate My Weekly Improvement Plan").disabled)
        self.assertIsNone(self.app.selectbox(key="selected_game").value)

    def test_empty_history_and_notation_only_pdf_are_explained(self):
        self.fetch.return_value = []
        self.kb.ingest_pdf.return_value = 0
        self.fetch_games()
        self.assertIn("No completed games", self.text())
        self.app.file_uploader[0].set_value(("moves.pdf", b"%PDF-moves", "application/pdf"))
        self.run_app()
        self.assertIn("No explanatory text", self.text())
        self.assertFalse(self.app.dataframe)

    def test_book_search_failure_has_an_immediate_retry_and_keeps_weekly_plan_usable(self):
        self.kb.search_advice.side_effect = KnowledgeBaseError("Book search is temporarily unavailable.")
        self.fetch_games()
        self.choose()
        self.assertIsNotNone(self.button("Retry book search"))
        self.assertFalse(self.button("Generate My Weekly Improvement Plan").disabled)
        self.kb.search_advice.side_effect = None
        self.button("Retry book search").click()
        self.run_app()
        self.assertIn("Protect your pieces", self.text())

    def test_new_analysis_requires_regenerating_the_weekly_plan(self):
        self.fetch_games()
        self.choose()
        self.button("Generate My Weekly Improvement Plan").click()
        self.run_app()
        self.assertIn("Focus 1:", self.text())
        self.choose(1)
        self.assertNotIn("Focus 1:", self.text())
        self.button("Generate My Weekly Improvement Plan").click()
        self.run_app()
        self.assertIn("2 games · 4 blunders", self.text())

    def test_anthropic_selection_uses_the_configured_provider(self):
        self.stack.enter_context(patch.dict(os.environ, {"ANTHROPIC_API_KEY": "test-key", "ANTHROPIC_MODEL": "fixture-claude-model"}))
        client = MagicMock()
        client.chat = None
        factory = self.stack.enter_context(patch("anthropic.Anthropic", return_value=client))
        review = self.stack.enter_context(patch("core.coach.ChessCoach.review_blunder", return_value="A grounded review."))
        self.fetch_games()
        self.assertEqual(self.app.selectbox(key="coach_provider").value, "Anthropic")
        self.choose()
        factory.assert_called_once()
        review.assert_called_once()
        self.assertIn("A grounded review", self.text())

    def test_personal_review_fetches_and_analyzes_latest_game_with_no_book_or_plan_controls(self):
        self.config = replace(self.config, chess_com_username="player", user_rating=564, review_only=True)
        self.fetch.return_value = [game(2, white_username="player", white_rating=590)]
        self.run_app()
        self.assertEqual(self.app.text_input(key="username").value, "player")
        self.assertEqual(self.app.number_input(key="user_rating").value, 564)
        self.button("Fetch Games").click()
        self.run_app()
        self.assertEqual(len(self.analysis_calls), 1)
        self.assertIn("Nxe5", self.text())
        self.assertIn("bishop from f1 to c4", self.text())
        self.assertFalse(self.app.file_uploader)
        self.assertFalse(self.app.tabs)
        self.assertNotIn("Enable the AI coach", self.text())

    def test_primer_teaches_all_three_chapters_and_game_review_stays_available(self):
        self.config = replace(self.config, review_only=True, chess_com_username="player", user_rating=564)
        self.run_app()
        self.assertEqual(self.app.radio(key="main_section").value, "Your games")
        self.app.radio(key="main_section").set_value("The Soviet Chess Primer")
        self.run_app()
        options = list(self.app.selectbox(key="primer_lesson").options)
        self.assertTrue(any("The board and the armies" in option for option in options))
        self.assertTrue(all(option.startswith("Chapter 1") for option in options))
        self.app.selectbox(key="primer_chapter").select(3)
        self.run_app()
        self.assertTrue(all(option.startswith("Chapter 3") for option in self.app.selectbox(key="primer_lesson").options))
        self.app.selectbox(key="primer_lesson").select("counterplan")
        self.run_app()
        self.assertEqual(self.app.selectbox(key="primer_lesson").value, "counterplan")
        self.app.selectbox(key="primer_chapter").select(1)
        self.run_app()
        self.assertIn("The board and the armies", self.text())
        self.assertIn("Or choose the move by name", self.text())
        self.button("Next").click()
        self.run_app()
        self.assertIn("Queens stand on d1", self.text())
        self.button("e4").click()
        self.run_app()
        self.assertIn("The king starts on e1", self.text())
        self.button("Try again").click()
        self.run_app()
        self.app.button(key="quiz-board-setup-e2-1-PP-light").click()
        self.run_app()
        self.app.button(key="quiz-board-setup-e4-1-E-light").click()
        self.run_app()
        self.assertIn("You played e4.", self.text())
        self.assertIn("The king starts on e1", self.text())
        self.app.radio(key="main_section").set_value("Your games")
        self.run_app()
        self.button("Fetch Games").click()
        self.run_app()
        self.assertEqual(len(self.analysis_calls), 1)

    def test_new_chapters_are_navigable_and_their_saved_place_is_restored(self):
        from core.primer_progress import LearningProgress
        self.config = replace(self.config, review_only=True, chess_com_username="player")
        store = LearningProgress(self.config.sqlite_path.parent / "primer.sqlite3", "player")
        store.bookmark("ch7-queen")
        self.run_app()
        self.app.radio(key="main_section").set_value("The Soviet Chess Primer")
        self.run_app()
        self.assertEqual(self.app.selectbox(key="primer_chapter").value, 7)
        self.assertEqual(self.app.selectbox(key="primer_lesson").value, "ch7-queen")
        self.assertIn("printed pages 247–248", self.text())
        self.app.button(key="example_next_ch7-queen_0").click()
        self.run_app()
        self.assertIn("blocks the h5–f7 diagonal", self.text())
        self.button("g6").click()
        self.run_app()
        self.assertIn("board", store.passed("ch7-queen"))
        for chapter in (4, 5, 6, 7):
            self.app.selectbox(key="primer_chapter").select(chapter)
            self.run_app()
            self.assertTrue(all(option.startswith(f"Chapter {chapter}") for option in self.app.selectbox(key="primer_lesson").options))
            self.assertIn("Book reference: printed pages", self.text())
            self.assertEqual([tab.label for tab in self.app.tabs], ["Learn", "Worked examples", "Practice", "Review"])
        self.assertIn("chapters 1–10", self.text())
        self.assertIn("appendix is not yet taught", self.text())
        self.assertNotIn("Chapters 11–10", self.text())

    def test_part_two_bookmark_replay_practice_and_chapter_navigation(self):
        from core.primer_progress import LearningProgress
        self.config = replace(self.config, review_only=True, chess_com_username="player")
        store = LearningProgress(self.config.sqlite_path.parent / "primer.sqlite3", "player")
        store.bookmark("ch10-symmetry")
        self.run_app()
        self.app.radio(key="main_section").set_value("The Soviet Chess Primer")
        self.run_app()
        self.assertEqual(self.app.selectbox(key="primer_chapter").value, 10)
        self.assertEqual(self.app.selectbox(key="primer_lesson").value, "ch10-symmetry")
        self.app.button(key="example_next_ch10-symmetry_0").click()
        self.run_app()
        self.assertIn("immediately copies the capture", self.text())
        self.button("d6").click()
        self.run_app()
        self.assertIn("board", store.passed("ch10-symmetry"))
        for chapter in (8, 9, 10):
            self.app.selectbox(key="primer_chapter").select(chapter)
            self.run_app()
            self.assertTrue(all(option.startswith(f"Chapter {chapter}") for option in self.app.selectbox(key="primer_lesson").options))
            self.assertIn("Book reference: printed pages", self.text())
            self.assertEqual([tab.label for tab in self.app.tabs], ["Learn", "Worked examples", "Practice", "Review"])
        self.assertIn("board", store.passed("ch10-symmetry"))

    def test_primer_guide_shows_book_pages_replays_examples_and_saves_checked_answers(self):
        self.config = replace(self.config, review_only=True, chess_com_username="player")
        guide = {
            "pages": (13, 14), "goals": ("Keep the king safe.",),
            "sections": ({"title": "Why safety matters", "body": "A king cannot move to an attacked square."},),
            "examples": ({"title": "Develop with a purpose", "fen": chess.STARTING_FEN, "moves": ("e4", "e5", "Nf3"), "notes": ("Start.", "White takes space.", "Black contests the center.", "The knight attacks e5.")},),
            "pitfalls": ("Checking is not always checkmate.",),
            "checks": ({"id": "king-safety", "prompt": "May your king move into check?", "options": (
                {"text": "Yes", "correct": False, "explanation": "Moving into check is illegal."},
                {"text": "No", "correct": True, "explanation": "The king must always stay safe."},
            )},), "recap": ("Examine enemy attacks before moving your king.",),
        }
        self.stack.enter_context(patch("core.primer_ui.guide_for", return_value=guide))
        self.run_app()
        self.app.radio(key="main_section").set_value("The Soviet Chess Primer")
        self.run_app()
        self.assertIn("Book reference: printed pages 13–14", self.text())
        self.assertIn("Why safety matters", self.text())
        self.assertFalse(any(slider.label == "Move through the example" for slider in self.app.slider))
        self.assertTrue(self.app.button(key="example_previous_board-setup_0").disabled)
        for _ in range(3):
            self.app.button(key="example_next_board-setup_0").click()
            self.run_app()
        self.assertIn("The knight attacks e5.", self.text())
        self.assertTrue(self.app.button(key="example_next_board-setup_0").disabled)
        self.app.button(key="example_previous_board-setup_0").click()
        self.run_app()
        self.assertIn("Black contests the center.", self.text())
        self.assertFalse(self.app.button(key="example_next_board-setup_0").disabled)
        self.app.radio(key="concept_choice_board-setup_king-safety").set_value(1)
        self.run_app()
        self.app.button(key="concept_check_board-setup_king-safety").click()
        self.run_app()
        self.assertIn("The king must always stay safe", self.text())
        self.app.radio(key="concept_choice_board-setup_king-safety").set_value(0)
        self.run_app()
        self.assertNotIn("The king must always stay safe", self.text())
        self.assertIn("Check your changed answer", self.text())
        from core.primer_progress import LearningProgress
        saved = LearningProgress(self.config.sqlite_path.parent / "primer.sqlite3", "player")
        self.assertIn("concept:king-safety", saved.passed("board-setup"))

    def test_coaching_uses_current_rating_instead_of_historical_game_rating(self):
        self.config = replace(self.config, openai_api_key="test-key", user_rating=564)
        self.stack.enter_context(patch("openai.OpenAI", return_value=MagicMock()))
        review = self.stack.enter_context(patch("core.coach.ChessCoach.review_blunder", return_value="Beginner feedback."))
        self.fetch_games()
        self.choose()
        self.assertEqual(review.call_args.kwargs["user_rating"], 564)
        self.app.number_input(key="user_rating").set_value(580)
        self.run_app()
        self.assertEqual(review.call_args.kwargs["user_rating"], 580)

    def test_primer_switching_player_restores_their_place_and_keeps_progress_separate(self):
        from core.primer import lessons
        from core.primer_progress import LearningProgress
        self.config = replace(self.config, review_only=True, chess_com_username="Alice")
        path = self.config.sqlite_path.parent / "primer.sqlite3"
        alice = LearningProgress(path, "Alice")
        bob = LearningProgress(path, "Bob")
        alice.bookmark("rook")
        bob.bookmark("queen-mates")
        self.run_app()
        self.app.radio(key="main_section").set_value("The Soviet Chess Primer")
        self.run_app()
        self.assertEqual(self.app.selectbox(key="primer_lesson").value, "rook")
        rook = next(item for item in lessons() if item.id == "rook")
        self.button(next(choice.san for choice in rook.choices if choice.correct)).click()
        self.run_app()
        self.assertTrue(self.app.session_state["primer_board_fen"])
        self.app.text_input(key="username").set_value(" Bob ")
        self.button("Fetch Games").click()
        self.run_app()
        self.assertEqual(self.app.selectbox(key="primer_lesson").value, "queen-mates")
        self.assertEqual(self.app.selectbox(key="primer_chapter").value, 2)
        self.assertIsNone(self.app.session_state["primer_board_fen"])
        self.button("Qg7#").click()
        self.run_app()
        self.assertIn("board", bob.passed("queen-mates"))
        self.assertNotIn("board", alice.passed("queen-mates"))
        self.app.text_input(key="username").set_value("Alice")
        self.button("Fetch Games").click()
        self.run_app()
        self.assertEqual(self.app.selectbox(key="primer_lesson").value, "rook")


if __name__ == "__main__":
    unittest.main()
