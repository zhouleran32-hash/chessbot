# ChessBot handoff for Cursor

Open and work directly in this existing project folder:

`the project folder`

This is the working copy already built with Codex. Read and edit these files
directly; do not create another project or extract a separate copy from the ZIP.

We are building ChessBot, a Python Streamlit app that fetches my public
Chess.com games and analyzes my mistakes with python-chess and Stockfish.
The Chess.com username and rating come from `.env`.
The current priority is detailed teaching from **The Soviet Chess Primer**,
now extended through chapter 10, including Part Two (chapters 8–10). Keep the game-review
feature available alongside the Primer. Teach why each idea works, show legal
connected examples and opponent replies, explain wrong answers, and check
understanding. The appendix is not yet taught. Do not claim
every printed puzzle or variation has been reproduced. Book uploads and weekly
plans remain available in full mode.

Chapters 1–7 retain their 175 reviewed lessons. Part Two adds 86 lessons: 36 in
chapter 8 (endgames), 32 in chapter 9 (middlegames), and 18 in chapter 10
(opening theory). The total course has 261 lessons, 348 annotated examples and
523 conceptual checks, with source-page references and saved progress.
Preserve the original lesson IDs and the regression tests. Compare legal move
identities when grading, accept valid alternatives to open-ended tasks, and
stop worked lines when the game ends. Distinguish an illustrative defensive
reply from a forced one, and distinguish practice completion from mastery.
Preserve selection-only Chapter/Lesson/Game menus and the < and > buttons
below the worked-example boards. Reports and source maps for this expansion
are under work/primer-expansion/ and work/primer-part2/.
The source/engine discrepancy for diagram 372 is explicitly qualified in the
course. Preserve this distinction and do not turn finite-depth engine results
or one historical game into an unsupported forced-win claim.

Start by reading `README.md`, `app.py`, and the relevant files under `core/`:

- `config.py`: environment settings, current coaching rating, review-only mode.
- `chess_client.py`: public Chess.com API ingestion without an API key.
- `analyzer.py`: Stockfish evaluation, blunder detection, board SVG arrows.
- `coach.py`: AI reviews and position-based feedback without an AI key.
- `rag_engine.py`: optional PDF/Chroma knowledge base.
- `primer.py`, `primer_chapter*.py`: lesson positions and objective-based grading.
- `primer_guides_chapter*.py`: source-mapped detailed explanations, examples, and questions.
- `primer_study.py`, `primer_ui.py`: validated replay and the guided learning interface.
- `primer_progress.py`: persistent per-player practice progress and bookmarks.

Keep the configured current rating as the coaching level, even when an older
game records another rating. Preserve session caching and explicit retries.
Use real Stockfish when available and label any explicitly enabled mock mode.
Do not invent accuracy scores, tactical continuations, or book citations.

Local settings are in `.env`; preserve them and do not expose credentials.
No AI key is required for the existing position-based feedback. The project
currently has a verification environment at `work/verify-env/` and a configured
local Stockfish executable. Dependencies are listed in `requirements.txt`.

From the project root, verify with:

```sh
work/verify-env/bin/python -m unittest discover -s tests
```

Run the suite to check the current count, including curriculum/chess/UI regressions. The dashboard is
currently served at `http://127.0.0.1:8501/`; reuse it if it is still running.
To start it when needed:

```sh
work/verify-env/bin/python -m streamlit run app.py
```

First confirm that this folder is open, inspect the current implementation,
and give me a brief overview of how game fetching, analysis, and feedback work.
Wait for my next requested change before modifying application behavior.
