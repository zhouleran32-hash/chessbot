"""Interactive ChessBot dashboard. Run with: streamlit run app.py."""

import hashlib
import io
import os
from pathlib import Path
import time
from datetime import datetime

import chess
import chess.pgn
import streamlit as st

from core.analyzer import EngineUnavailableError, GameAnalysisError, GameAnalyzer
from core.chess_client import ChessDotComClient, ChessDotComError
from core.coach import ChessCoach, CoachingError
from core.config import load_config
from core.primer_ui import render_primer
from core.rag_engine import ChessBookKnowledgeBase, KnowledgeBaseError


def _retry_cached(cache_name: str, key) -> None:
    """Clear a failed attempt before the button's normal Streamlit rerun."""
    st.session_state[cache_name].pop(key, None)


def _initialize_session(config) -> None:
    defaults = {
        "games": [], "loaded_username": "", "analyses": {}, "reviews": {},
        "book_advice": {}, "weekly_plan": None, "book_uploads": {},
        "library_revision": 0, "fetch_error": None,
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value
    if "knowledge_base" not in st.session_state:
        st.session_state.knowledge_base = ChessBookKnowledgeBase(
            persist_directory=config.chroma_dir, openai_api_key=config.openai_api_key or None,
        )


def _engine_status(path: str, refresh: bool) -> dict:
    status = st.session_state.get("engine_status")
    if refresh or not status or status["path"] != path or time.monotonic() - status["checked"] > 60:
        try:
            with GameAnalyzer(path, time_limit=0.01, depth=1):
                status = {"ready": True, "message": "Stockfish is ready"}
        except EngineUnavailableError as error:
            status = {"ready": False, "message": str(error)}
        status.update(path=path, checked=time.monotonic())
        st.session_state.engine_status = status
    return status


def _fetch_games(username: str, *, select_latest: bool = False) -> None:
    st.session_state.fetch_error = None
    if not username.strip():
        st.session_state.fetch_error = "Enter a Chess.com username first."
        return
    try:
        with st.spinner("Finding your latest games…"):
            games = ChessDotComClient().get_recent_games(username, count=10)
    except (ChessDotComError, ValueError) as error:
        st.session_state.fetch_error = str(error)
        return

    normalized = username.strip().lower()
    if normalized != st.session_state.loaded_username:
        st.session_state.analyses = {}
        st.session_state.reviews = {}
        st.session_state.weekly_plan = None
        st.session_state.pop("selected_game", None)
    elif st.session_state.get("selected_game") not in {game["game_url"] for game in games}:
        st.session_state.pop("selected_game", None)
    st.session_state.games = games
    st.session_state.loaded_username = normalized
    if select_latest and games:
        st.session_state.selected_game = games[0]["game_url"]


def _book_uploader(config) -> None:
    uploaded = st.file_uploader("Feed a Chess Book", type=["pdf"], key="book_pdf")
    st.caption("Text PDFs become searchable book passages. Scans need OCR first.")
    if uploaded is None:
        return
    content = uploaded.getvalue()
    digest = hashlib.sha256(content).hexdigest()
    previous = st.session_state.book_uploads.get(digest)
    if previous is None:
        # Keep citations readable while isolating different files with the same name.
        filename = Path(uploaded.name.replace("\\", "/")).name
        if filename in {"", ".", ".."}:
            filename = "chess-book.pdf"
        target = config.books_dir / digest / filename
        try:
            with st.spinner("Reading and indexing your chess book…"):
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(content)
                chunks = st.session_state.knowledge_base.ingest_pdf(str(target))
            previous = {"name": filename, "chunks": chunks}
            if chunks:
                st.session_state.library_revision += 1
                st.session_state.reviews = {}
                st.session_state.book_advice = {}
        except (KnowledgeBaseError, OSError, ValueError) as error:
            previous = {"name": filename, "error": str(error)}
        st.session_state.book_uploads[digest] = previous
    if previous.get("error"):
        st.error(previous["error"])
        st.button("Retry indexing", on_click=_retry_cached, args=("book_uploads", digest))
    elif previous["chunks"]:
        st.success(f"Indexed {previous['name']} · {previous['chunks']} passages")
    else:
        st.warning("No explanatory text was found. Try a text PDF or run OCR on this book.")


def _sidebar(config) -> tuple[dict, bool, str, str | None]:
    with st.sidebar:
        st.title("♟ ChessBot")
        st.caption("YOUR PERSONAL CHESS COACH")
        with st.form("fetch_games_form"):
            username = st.text_input("Chess.com username", value=config.chess_com_username, key="username", placeholder="Your username")
            if st.form_submit_button("Fetch Games", type="primary", width="stretch"):
                _fetch_games(username, select_latest=config.review_only)
        st.number_input("Your current rating", min_value=0, max_value=4000, value=config.user_rating, step=1, key="user_rating", help="Feedback is tailored to this rating, even when an older game has a different rating.")
        if st.session_state.fetch_error:
            st.error(st.session_state.fetch_error)
        if st.session_state.loaded_username:
            st.caption(f"Loaded: {st.session_state.loaded_username} · {len(st.session_state.games)} recent games")
        st.divider()
        st.subheader("Engine")
        refresh = st.button("Check again", help="Recheck your configured Stockfish executable.")
        status = _engine_status(config.stockfish_path, refresh)
        if status["ready"]:
            st.success("Stockfish is ready")
            allow_mock = False
        else:
            st.warning("Stockfish is unavailable")
            allow_mock = st.checkbox("Use mock analysis", value=False, key="allow_mock", help="Development only: a simple material search, with no Stockfish accuracy.")
            with st.expander("Set up Stockfish"):
                st.write(status["message"])
                st.markdown("[Download Stockfish](https://stockfishchess.org/download/) and set `STOCKFISH_PATH` in `.env`.")
        anthropic_key = os.getenv("ANTHROPIC_API_KEY", "").strip()
        anthropic_model = os.getenv("ANTHROPIC_MODEL", "").strip()
        use_anthropic = not config.openai_api_key and anthropic_key and anthropic_model
        if config.review_only:
            provider = "Anthropic" if use_anthropic else "OpenAI · GPT-4o"
        else:
            st.divider()
            st.subheader("Your chess library")
            _book_uploader(config)
            st.caption("Book indexing and semantic search use OPENAI_API_KEY. Until a book is indexed, beginner principles are available for free.")
            st.divider()
            st.subheader("AI coach")
            provider = st.selectbox(
                "Coach provider", ["OpenAI · GPT-4o", "Anthropic"], key="coach_provider",
                index=1 if use_anthropic else 0, filter_mode=None,
            )
        ready = bool(config.openai_api_key) if provider.startswith("OpenAI") else bool(anthropic_key and anthropic_model)
        if ready:
            st.caption("AI reviews are enabled for the blunder you view.")
        elif not config.review_only:
            setting = "OPENAI_API_KEY" if provider.startswith("OpenAI") else "ANTHROPIC_API_KEY and ANTHROPIC_MODEL"
            st.caption(f"Add {setting} to .env to enable AI reviews.")
        else:
            st.caption("Position-based feedback is ready. No AI key is needed.")
        st.caption("Games and analyses stay in this session.")
    return status, allow_mock, provider, anthropic_model or None


def _date_label(game: dict) -> str:
    return datetime.fromisoformat(game["played_at"]).strftime("%d %b %Y · %H:%M")


def _game_label(game: dict) -> str:
    opponent = game["black_username"] if game["user_color"] == "white" else game["white_username"]
    return f"{_date_label(game)} · vs {opponent} · {game['result'].title()}"


def _analyze(game: dict, config, status: dict, allow_mock: bool) -> dict | None:
    signature = hashlib.sha256(repr((
        game["pgn"], game["user_color"], config.stockfish_path, status["ready"], allow_mock,
    )).encode()).hexdigest()
    record = st.session_state.analyses.get(game["game_url"])
    if record and record["signature"] != signature:
        del st.session_state.analyses[game["game_url"]]
        st.session_state.weekly_plan = None
        record = None
    if not status["ready"] and not allow_mock:
        st.info("Set STOCKFISH_PATH or enable mock analysis in the sidebar to review this game.")
        return None
    if record is None:
        progress = st.progress(0.0, text="Preparing your game…")

        def update(done: int, total: int) -> None:
            progress.progress(done / max(total, 1), text=f"Reviewing moves · {done} of {total}")

        try:
            with GameAnalyzer(config.stockfish_path, time_limit=0.1, allow_mock=allow_mock) as analyzer:
                blunders = analyzer.analyze_game(game["pgn"], game["user_color"], progress_callback=update)
                is_mock = analyzer.is_mock
            parsed = chess.pgn.read_game(io.StringIO(game["pgn"]))
            color = chess.WHITE if game["user_color"] == "white" else chess.BLACK
            player_moves = sum(node.parent.board().turn == color for node in parsed.mainline())
            record = {"signature": signature, "blunders": blunders, "is_mock": is_mock, "player_moves": player_moves}
            st.session_state.weekly_plan = None
        except (GameAnalysisError, ValueError) as error:
            record = {"signature": signature, "error": str(error)}
        finally:
            progress.empty()
        st.session_state.analyses[game["game_url"]] = record
    if record.get("error"):
        st.error(record["error"])
        st.button("Retry analysis", on_click=_retry_cached, args=("analyses", game["game_url"]))
        return None
    return record


def _book_principles(category: str) -> None:
    key = (st.session_state.library_revision, category)
    cache = st.session_state.book_advice
    cached = cache.get(key)
    if cached is None:
        try:
            excerpts = st.session_state.knowledge_base.search_advice(ChessCoach.CATEGORY_DETAILS[category]["query"], n_results=1)
            cached = {"excerpts": excerpts}
        except (KnowledgeBaseError, ValueError) as error:
            cached = {"error": str(error)}
        cache[key] = cached
    st.markdown("**A principle to practice**")
    if cached.get("error"):
        st.warning(cached["error"])
        st.button("Retry book search", on_click=_retry_cached, args=("book_advice", key))
    else:
        for excerpt in cached["excerpts"]:
            st.markdown(excerpt)
    st.markdown(f"**Your mental check**\n\n{ChessCoach.CATEGORY_DETAILS[category]['mental_check']}")


def _coaching(game: dict, record: dict, index: int, config, provider: str, anthropic_model: str | None) -> None:
    blunder = record["blunders"][index]
    category = ChessCoach.classify_blunder(blunder["fen_before"], blunder["played_move"], blunder["best_move"])
    st.caption(f"Practice theme: {ChessCoach.CATEGORY_DETAILS[category]['title']} · suggested by board patterns")
    is_openai = provider.startswith("OpenAI")
    api_key = config.openai_api_key if is_openai else os.getenv("ANTHROPIC_API_KEY", "").strip()
    rating = st.session_state.get("user_rating", config.user_rating)
    if not api_key or (not is_openai and not anthropic_model):
        st.caption("Position-based feedback · immediate legal threats and the suggested move")
        st.markdown(ChessCoach.review_blunder_locally(blunder["fen_before"], blunder["played_move"], blunder["best_move"], user_rating=rating))
        if not config.review_only:
            _book_principles(category)
        return
    key = (game["game_url"], record["signature"], index, st.session_state.library_revision, provider, anthropic_model, rating)
    cached = st.session_state.reviews.get(key)
    if cached is None:
        try:
            with st.spinner("Your coach is reviewing this position…"):
                if is_openai:
                    from openai import OpenAI
                    client = OpenAI(api_key=api_key, max_retries=0, timeout=30)
                else:
                    from anthropic import Anthropic
                    client = Anthropic(api_key=api_key, max_retries=0, timeout=30)
                with client:
                    coach = ChessCoach(client, st.session_state.knowledge_base, model="gpt-4o" if is_openai else anthropic_model)
                    review = coach.review_blunder(
                        fen=blunder["fen_before"], played_move=blunder["played_move"],
                        best_move=blunder["best_move"], eval_drop=blunder["eval_drop"], user_rating=rating,
                    )
            cached = {"text": review}
        except CoachingError as error:
            cached = {"error": str(error)}
        except Exception:
            # SDK initialization errors can contain configuration values; keep those private.
            cached = {"error": "The AI coach could not start. Check your provider settings and try again."}
        st.session_state.reviews[key] = cached
    if cached.get("error"):
        st.warning(cached["error"])
        st.button("Retry coaching", on_click=_retry_cached, args=("reviews", key))
        st.markdown(ChessCoach.review_blunder_locally(blunder["fen_before"], blunder["played_move"], blunder["best_move"], user_rating=rating))
        if not config.review_only:
            _book_principles(category)
    else:
        st.markdown(cached["text"])


def _game_review(config, status: dict, allow_mock: bool, provider: str, anthropic_model: str | None) -> None:
    games = st.session_state.games
    if not games:
        if st.session_state.loaded_username:
            st.info(f"No completed games were found for {st.session_state.loaded_username}. Try another username or check back after playing.")
        else:
            st.info("Start with your games: enter a Chess.com username and choose Fetch Games in the sidebar.")
        st.markdown("#### Turn a mistake into a habit\nPick a game, explore the moves that mattered, and leave with one clear question to ask before your next move.")
        return
    st.subheader("Recent games")
    st.caption(f"Latest completed games for {st.session_state.loaded_username}. Results are from this player's perspective.")
    st.dataframe([
        {"White": f"{game['white_username']} ({game['white_rating'] or '—'})",
         "Black": f"{game['black_username']} ({game['black_rating'] or '—'})",
         "Result": game["result"].title(), "Date (UTC)": _date_label(game)}
        for game in games
    ], hide_index=True, width="stretch", height=210 if config.review_only else "auto")
    by_url = {game["game_url"]: game for game in games}
    selected = st.selectbox("Choose a game", list(by_url), index=None, key="selected_game", format_func=lambda url: _game_label(by_url[url]), placeholder="Select a game to start your review", filter_mode=None)
    if selected is None:
        return
    game = by_url[selected]
    st.divider()
    st.subheader("Your game review")
    st.caption(f"You played {game['user_color']} · {_game_label(game)} (UTC)")
    record = _analyze(game, config, status, allow_mock)
    if record is None:
        return
    if record["is_mock"]:
        st.warning("Mock analysis · development preview using a simple material search. These findings are not Stockfish evaluations.")
    columns = st.columns(3)
    accuracy = game.get("accuracy")
    columns[0].metric("Accuracy", f"{accuracy:.1f}%" if accuracy is not None else "—", help="Published Chess.com accuracy for this player, when supplied by the API.")
    columns[1].metric("Blunders", len(record["blunders"]))
    columns[2].metric("Moves reviewed", record["player_moves"])
    if accuracy is None:
        st.caption("Chess.com did not publish an accuracy score for this game.")
    else:
        st.caption("Accuracy is the score published by Chess.com; blunders below use the selected analyzer.")
    st.caption("Blunders lose more than 1.5 pawns in evaluation. Red arrow: played move. Green arrow: suggested move.")
    blunders = record["blunders"]
    if not blunders:
        st.success("No blunders above the 1.5-pawn threshold were found in this game.")
        st.caption("Keep checking your opponent's checks, captures, and threats before each move.")
        return
    number = st.slider("Blunder", 1, len(blunders), 1, key=f"blunder_{record['signature']}") if len(blunders) > 1 else 1
    blunder = blunders[number - 1]
    st.markdown(f"#### Blunder {number} of {len(blunders)} · Move {blunder['move_number']}")
    board_column, coach_column = st.columns([1, 1.25], gap="large")
    with board_column:
        st.image(blunder["board_svg"], width="stretch", alt=f"Position before move {blunder['move_number']}, with played and recommended move arrows")
        st.caption(f"Position before your move · {game['user_color'].title()} at the bottom")
        with st.expander("Position details"):
            st.code(blunder["fen_before"], language=None)
    with coach_column:
        played, best = st.columns(2)
        played.metric("You played", blunder["played_move"])
        best.metric("Suggested move" if record["is_mock"] else "Best move", blunder["best_move"])
        st.caption(f"Evaluation loss: {blunder['eval_drop']:.2f} pawns")
        _coaching(game, record, number - 1, config, provider, anthropic_model)


def _improvement_plan() -> None:
    st.subheader("A small plan. A stronger next game.")
    records = [record for record in st.session_state.analyses.values() if not record.get("error")]
    st.caption(f"Based on {len(records)} game{'s' if len(records) != 1 else ''} analyzed in this session. Each game counts once.")
    if st.button("Generate My Weekly Improvement Plan", type="primary", disabled=not records):
        st.session_state.weekly_plan = ChessCoach.generate_weekly_plan(records)
    if not records:
        st.info("Review a game first, then come back for three focused practice exercises.")
        return
    if any(record["is_mock"] for record in records):
        st.warning("This session includes mock analysis. Use Stockfish for a reliable practice plan.")
    plan = st.session_state.weekly_plan
    if plan is None:
        st.write("Build a weekly routine around the patterns in your games. No AI key is needed.")
        return
    game_count, blunder_count = plan["games_analyzed"], plan["total_blunders"]
    st.markdown(f"**{game_count} game{'s' if game_count != 1 else ''} · {blunder_count} blunder{'s' if blunder_count != 1 else ''} · 3 practice focuses**")
    for item in plan["practice_plan"]:
        with st.container(border=True):
            st.markdown(f"#### {item['title']}")
            st.caption(item["reason"])
            st.write(item["practice"])
            st.markdown(f"**Before you move:** {item['mental_check']}")


def main() -> None:
    st.set_page_config(page_title="ChessBot · Your chess coach", page_icon="♟", layout="wide")
    config = load_config()
    _initialize_session(config)
    status, allow_mock, provider, anthropic_model = _sidebar(config)
    st.title("ChessBot")
    if config.review_only:
        st.write("Understand your mistakes, find a better move, and build good habits.")
        st.caption(f"Coaching level: {st.session_state.user_rating} rating · beginner explanations" if st.session_state.user_rating < 1000 else f"Coaching level: {st.session_state.user_rating} rating")
        section = st.radio("Open", ["Your games", "The Soviet Chess Primer"], horizontal=True, key="main_section", label_visibility="collapsed")
        if section == "The Soviet Chess Primer":
            render_primer(config)
            return
        _game_review(config, status, allow_mock, provider, anthropic_model)
        return
    st.write("Understand the move. Learn the principle. Play with a plan.")
    review_tab, plan_tab, primer_tab = st.tabs(["Game review", "Improvement plan", "The Soviet Chess Primer"])
    with review_tab:
        _game_review(config, status, allow_mock, provider, anthropic_model)
    with plan_tab:
        _improvement_plan()
    with primer_tab:
        render_primer(config)


if __name__ == "__main__":
    main()
